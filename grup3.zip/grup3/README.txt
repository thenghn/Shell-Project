İşletim Sistemleri Proje Ödevi (Grup 3)

Grup Üyeleri
Rabia Abdioğlu, B201210302, 1-B
Nagihan Yalçın, G201210301, 2-A  
Enes Kayri, G171210302, 1-B 
Hüseyin Öztürk, G171210302, 1-B
Mehmet Yalçın, G191210089, 2-B  

Dosyaların ve Dizinlerin Listesi

grup3 #Proje dosyası
├── sau                   
│   ├── shell.c         #Kabuk kaynak kod dosyası
│   └── test             #Test 
├── 1.png       # Program çıktısı
├── 2.png       # Program çıktısı
├── 3.png       # Program çıktısı
└── README.txt #Readme metin dosyası

Programı Derlemek İçin Talimatlar

cd Masaüstü/grup3/sau
gcc shell.c -o test 

Programları / Komut Dosyalarını Çalıştırmak İçin Talimatlar

./test 

Geliştirme Sırasında Karşılaşılan Zorluklar

Projeyi geliştirme sırasında uygun kaynakları bulup özümseme süreci karşılaştığımız zorlukların başında yer almaktadır. Yerli ve yabancı birçok kaynağın taranmasına rağmen bazı sorulara cevap bulmakta epey güçlük çekilmiştir. Özellikle, proje dosyasındaki 5.bölümde yer alan built-in komutların yazımı sırasında özellikle showpid ve cd'yle ilişkili karşılaşılan bazı hatalar olmuş ve bu hataların büyük çoğu çözüme ulaştırılmıştır. C kitaplığı çağrısı memset() kullanımında sıkıntılarla karşılaşılmıştır. Bu konu üzerine birçok inceleme ve deneme yapılsa da showpid ile memset() fonksiyonu birlikte çalışmamaktadır. Kabuk tarafından oluşturulmuş en az 5 yavru proses pid'sinin ekrana yazdırılmasıyla ilgili sınırlandırma da projenin geliştirilmesi sırasında zorlandırıcı bir detay olarak karşımıza çıkmıştır. 

Programın Yazımında Kullanılan Yardımcı Kaynaklar

http://www.cse.csusb.edu/tongyu/courses/cs460/notes/intro.php
https://linux.die.net/man/3/execvp
https://iq.opengenus.org/chdir-fchdir-getcwd-in-c/
https://stackoverflow.com/questions/28502305/writing-a-simple-shell-in-c-using-fork-execvp
https://www.geeksforgeeks.org/making-linux-shell-c/
https://github.com/pranjalbajaj/NEKTech-Linux-Shell
https://brennan.io/2015/01/16/write-a-shell-in-c/
